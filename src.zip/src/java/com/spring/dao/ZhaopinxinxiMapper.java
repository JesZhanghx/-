package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Zhaopinxinxi;

import org.springframework.stereotype.Repository;


@Repository
public interface ZhaopinxinxiMapper extends MapperBase<Zhaopinxinxi> {
}
