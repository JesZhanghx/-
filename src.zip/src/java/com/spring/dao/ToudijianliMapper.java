package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Toudijianli;

import org.springframework.stereotype.Repository;


@Repository
public interface ToudijianliMapper extends MapperBase<Toudijianli> {
}
