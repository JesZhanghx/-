package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Qiye;

import org.springframework.stereotype.Repository;


@Repository
public interface QiyeMapper extends MapperBase<Qiye> {
    Qiye login(Qiye qiye);
}
