package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Lunbotu;

import org.springframework.stereotype.Repository;


@Repository
public interface LunbotuMapper extends MapperBase<Lunbotu> {
}
