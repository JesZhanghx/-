package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Fangxiangleixing;

import org.springframework.stereotype.Repository;


@Repository
public interface FangxiangleixingMapper extends MapperBase<Fangxiangleixing> {
}
