package com.spring.dao;

import com.base.MapperBase;
import com.spring.entity.Gonggaoxinxi;

import org.springframework.stereotype.Repository;


@Repository
public interface GonggaoxinxiMapper extends MapperBase<Gonggaoxinxi> {
}
