package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Gonggaofenlei;

public interface GonggaofenleiService extends IServiceBase<Gonggaofenlei> {
}
