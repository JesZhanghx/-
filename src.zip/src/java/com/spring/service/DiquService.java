package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Diqu;

public interface DiquService extends IServiceBase<Diqu> {
}
