package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Biyequxiang;

public interface BiyequxiangService extends IServiceBase<Biyequxiang> {
}
