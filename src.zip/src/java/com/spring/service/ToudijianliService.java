package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Toudijianli;

public interface ToudijianliService extends IServiceBase<Toudijianli> {
}
