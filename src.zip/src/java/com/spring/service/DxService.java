package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Dx;

public interface DxService extends IServiceBase<Dx> {
}
