package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.FangxiangleixingMapper;
import com.spring.entity.Fangxiangleixing;
import com.spring.service.FangxiangleixingService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("FangxiangleixingService")
public class FangxiangleixingServiceImpl extends ServiceBase<Fangxiangleixing> implements FangxiangleixingService {
    @Resource
    private FangxiangleixingMapper dao;

    @Override
    protected FangxiangleixingMapper getDao() {
        return dao;
    }
}
