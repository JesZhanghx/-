package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.GonggaofenleiMapper;
import com.spring.entity.Gonggaofenlei;
import com.spring.service.GonggaofenleiService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("GonggaofenleiService")
public class GonggaofenleiServiceImpl extends ServiceBase<Gonggaofenlei> implements GonggaofenleiService {
    @Resource
    private GonggaofenleiMapper dao;

    @Override
    protected GonggaofenleiMapper getDao() {
        return dao;
    }
}
