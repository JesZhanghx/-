package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.ToudijianliMapper;
import com.spring.entity.Toudijianli;
import com.spring.service.ToudijianliService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("ToudijianliService")
public class ToudijianliServiceImpl extends ServiceBase<Toudijianli> implements ToudijianliService {
    @Resource
    private ToudijianliMapper dao;

    @Override
    protected ToudijianliMapper getDao() {
        return dao;
    }
}
