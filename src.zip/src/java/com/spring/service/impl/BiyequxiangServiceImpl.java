package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.BiyequxiangMapper;
import com.spring.entity.Biyequxiang;
import com.spring.service.BiyequxiangService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("BiyequxiangService")
public class BiyequxiangServiceImpl extends ServiceBase<Biyequxiang> implements BiyequxiangService {
    @Resource
    private BiyequxiangMapper dao;

    @Override
    protected BiyequxiangMapper getDao() {
        return dao;
    }
}
