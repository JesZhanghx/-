package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.QiyeMapper;
import com.spring.entity.Qiye;
import com.spring.service.QiyeService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("QiyeService")
public class QiyeServiceImpl extends ServiceBase<Qiye> implements QiyeService {
    @Resource
    private QiyeMapper dao;

    @Override
    protected QiyeMapper getDao() {
        return dao;
    }
    public Qiye login(String username, String password) {
        Qiye user = new Qiye();
        user.setYonghuming(username);
            user.setMima(password);

        return this.dao.login(user);
    }

    public boolean updatePassword(int id, String newPassword) {
        Qiye user = new Qiye();
        user.setId(id);
            user.setMima(newPassword);
        int i = this.dao.updateByPrimaryKeySelective(user);
        return i == 1;
    }
}
