package com.spring.service.impl;

import com.base.ServiceBase;
import com.spring.dao.GonggaoxinxiMapper;
import com.spring.entity.Gonggaoxinxi;
import com.spring.service.GonggaoxinxiService;
import org.springframework.stereotype.Service;
import util.Info;

import javax.annotation.Resource;

@Service("GonggaoxinxiService")
public class GonggaoxinxiServiceImpl extends ServiceBase<Gonggaoxinxi> implements GonggaoxinxiService {
    @Resource
    private GonggaoxinxiMapper dao;

    @Override
    protected GonggaoxinxiMapper getDao() {
        return dao;
    }
}
