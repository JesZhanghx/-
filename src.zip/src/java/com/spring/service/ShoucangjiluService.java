package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Shoucangjilu;

public interface ShoucangjiluService extends IServiceBase<Shoucangjilu> {
}
