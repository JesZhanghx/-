package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Youqinglianjie;

public interface YouqinglianjieService extends IServiceBase<Youqinglianjie> {
}
