package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Qiye;

public interface QiyeService extends IServiceBase<Qiye> {
    public Qiye login(String username, String password);
    public boolean updatePassword(int id, String newPassword);
}
