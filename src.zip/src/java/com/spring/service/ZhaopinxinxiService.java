package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Zhaopinxinxi;

public interface ZhaopinxinxiService extends IServiceBase<Zhaopinxinxi> {
}
