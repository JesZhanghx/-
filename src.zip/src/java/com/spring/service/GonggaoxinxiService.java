package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Gonggaoxinxi;

public interface GonggaoxinxiService extends IServiceBase<Gonggaoxinxi> {
}
