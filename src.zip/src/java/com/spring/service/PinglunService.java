package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Pinglun;

public interface PinglunService extends IServiceBase<Pinglun> {
}
