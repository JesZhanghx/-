package com.spring.service;

import com.base.IServiceBase;
import com.spring.entity.Fangxiangleixing;

public interface FangxiangleixingService extends IServiceBase<Fangxiangleixing> {
}
