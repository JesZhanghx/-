package com.spring.controller;

import com.spring.dao.ZhaopinxinxiMapper;
import com.spring.entity.Zhaopinxinxi;
import com.spring.service.ZhaopinxinxiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;
import java.util.*;


import com.spring.entity.Qiye;
import com.spring.service.QiyeService;

/**
 * 招聘信息 */
@Controller
public class ZhaopinxinxiController extends BaseController
{
    @Autowired
    private ZhaopinxinxiMapper dao;
    @Autowired
    private ZhaopinxinxiService service;

    @Autowired
    private QiyeService serviceRead;
    /**
     *  后台列表页
     *
     */
    @RequestMapping("/zhaopinxinxi_list")
    public String list()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }

        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Zhaopinxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Zhaopinxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "zhaopinxinxi_list";
    }

    public String getWhere()
    {
        String where = " ";
        if(Request.getInt("qiyeid")>0){
            where += " AND qiyeid='"+Request.getInt("qiyeid")+"' ";
        }

            if(!Request.get("qiyemingcheng").equals("")) {
            where += " AND qiyemingcheng LIKE '%"+Request.get("qiyemingcheng")+"%' ";
        }
                if(!Request.get("xingbie").equals("")) {
            where += " AND xingbie ='"+Request.get("xingbie")+"' ";
        }
                if(!Request.get("zhiweimingcheng").equals("")) {
            where += " AND zhiweimingcheng LIKE '%"+Request.get("zhiweimingcheng")+"%' ";
        }
            return where;
    }

    @RequestMapping("/zhaopinxinxi_list_faburen")
    public String listfaburen()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Zhaopinxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " faburen='"+request.getSession().getAttribute("username")+"' ";
        where += getWhere();

        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }

        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Zhaopinxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "zhaopinxinxi_list_faburen";
    }


    /**
    *  前台列表页
    *
    */
    @RequestMapping("/zhaopinxinxilist")
    public String index()
    {
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Zhaopinxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Zhaopinxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        request.setAttribute("where" , where);
        assign("orderBy" , order);
        assign("sort" , sort);
        return "zhaopinxinxilist";
    }


        @RequestMapping("/zhaopinxinxi_add")
    public String add()
    {
        int id = Request.getInt("id");
        Qiye readMap = serviceRead.find(id);
        request.setAttribute("readMap" , readMap);
        return "zhaopinxinxi_add";
    }



    @RequestMapping("/zhaopinxinxi_updt")
    public String updt()
    {
        int id = Request.getInt("id");
        Zhaopinxinxi mmm = service.find(id);
        request.setAttribute("mmm" , mmm);
        request.setAttribute("updtself" , 0);
        return "zhaopinxinxi_updt";
    }
    /**
     * 添加内容
     * @return
     */
    @RequestMapping("/zhaopinxinxiinsert")
    public String insert()
    {
        String tmp="";
        Zhaopinxinxi post = new Zhaopinxinxi();
        post.setBianhao(Request.get("bianhao"));

        post.setQiyemingcheng(Request.get("qiyemingcheng"));

        post.setLianxidianhua(Request.get("lianxidianhua"));

        post.setLianxiren(Request.get("lianxiren"));

        post.setXueliyaoqiu(Request.get("xueliyaoqiu"));

        post.setXingbie(Request.get("xingbie"));

        post.setZhiweimingcheng(Request.get("zhiweimingcheng"));

        post.setZhiweiyaoqiu(Request.get("zhiweiyaoqiu"));

        post.setGongzuodidian(Request.get("gongzuodidian"));

        post.setZhaopairenshu(Request.getInt("zhaopairenshu"));

        post.setXinjin(Request.get("xinjin"));

        post.setQitadaiyu(Request.get("qitadaiyu"));

        post.setFaburen(Request.get("faburen"));

        post.setQiyeid(Request.getInt("qiyeid"));

        post.setAddtime(Info.getDateStr());
                service.insert(post);
        int charuid = post.getId().intValue();
        
        return showSuccess("保存成功" , Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
    * 更新内容
    * @return
    */
    @RequestMapping("/zhaopinxinxiupdate")
    public String update()
    {
        Zhaopinxinxi post = new Zhaopinxinxi();
        if(!Request.get("bianhao").equals(""))
        post.setBianhao(Request.get("bianhao"));
                if(!Request.get("qiyemingcheng").equals(""))
        post.setQiyemingcheng(Request.get("qiyemingcheng"));
                if(!Request.get("lianxidianhua").equals(""))
        post.setLianxidianhua(Request.get("lianxidianhua"));
                if(!Request.get("lianxiren").equals(""))
        post.setLianxiren(Request.get("lianxiren"));
                if(!Request.get("xueliyaoqiu").equals(""))
        post.setXueliyaoqiu(Request.get("xueliyaoqiu"));
                if(!Request.get("xingbie").equals(""))
        post.setXingbie(Request.get("xingbie"));
                if(!Request.get("zhiweimingcheng").equals(""))
        post.setZhiweimingcheng(Request.get("zhiweimingcheng"));
                if(!Request.get("zhiweiyaoqiu").equals(""))
        post.setZhiweiyaoqiu(Request.get("zhiweiyaoqiu"));
                if(!Request.get("gongzuodidian").equals(""))
        post.setGongzuodidian(Request.get("gongzuodidian"));
                if(!Request.get("zhaopairenshu").equals(""))
        post.setZhaopairenshu(Request.getInt("zhaopairenshu"));
            if(!Request.get("xinjin").equals(""))
        post.setXinjin(Request.get("xinjin"));
                if(!Request.get("qitadaiyu").equals(""))
        post.setQitadaiyu(Request.get("qitadaiyu"));
                if(!Request.get("faburen").equals(""))
        post.setFaburen(Request.get("faburen"));
        
        post.setId(Request.getInt("id"));
                service.update(post);
        int charuid = post.getId().intValue();
        
        if(Request.getInt("updtself") == 1){
            return showSuccess("保存成功" , "zhaopinxinxi_updtself.do");
        }
        return showSuccess("保存成功" , Request.get("referer"));
    }
    /**
     *  后台详情
     */
    @RequestMapping("/zhaopinxinxi_detail")
    public String detail()
    {
        int id = Request.getInt("id");
        Zhaopinxinxi map = service.find(id);
        request.setAttribute("map" , map);
        return "zhaopinxinxi_detail";
    }
    /**
     *  前台详情
     */
    @RequestMapping("/zhaopinxinxidetail")
    public String detailweb()
    {
        int id = Request.getInt("id");
        Zhaopinxinxi map = service.find(id);
        
        request.setAttribute("map" , map);
        return "zhaopinxinxidetail";
    }
        /**
    *  删除
    */
    @RequestMapping("/zhaopinxinxi_delete")
    public String delete()
    {
        if(!checkLogin()){
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
                service.delete(id);
                return showSuccess("删除成功",request.getHeader("referer"));
    }
}
