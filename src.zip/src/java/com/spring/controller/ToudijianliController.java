package com.spring.controller;

import com.spring.dao.ToudijianliMapper;
import com.spring.entity.Toudijianli;
import com.spring.service.ToudijianliService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;
import java.util.*;


import com.spring.entity.Zhaopinxinxi;
import com.spring.service.ZhaopinxinxiService;

/**
 * 投递简历 */
@Controller
public class ToudijianliController extends BaseController
{
    @Autowired
    private ToudijianliMapper dao;
    @Autowired
    private ToudijianliService service;

    @Autowired
    private ZhaopinxinxiService serviceRead;
    /**
     *  后台列表页
     *
     */
    @RequestMapping("/toudijianli_list")
    public String list()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }

        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Toudijianli.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Toudijianli> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "toudijianli_list";
    }

    public String getWhere()
    {
        String where = " ";
        if(Request.getInt("zhaopinxinxiid")>0){
            where += " AND zhaopinxinxiid='"+Request.getInt("zhaopinxinxiid")+"' ";
        }

            if(!Request.get("qiyemingcheng").equals("")) {
            where += " AND qiyemingcheng LIKE '%"+Request.get("qiyemingcheng")+"%' ";
        }
                if(!Request.get("zhiweimingcheng").equals("")) {
            where += " AND zhiweimingcheng LIKE '%"+Request.get("zhiweimingcheng")+"%' ";
        }
            return where;
    }

    @RequestMapping("/toudijianli_list_faburen")
    public String listfaburen()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Toudijianli.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " faburen='"+request.getSession().getAttribute("username")+"' ";
        where += getWhere();

        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }

        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Toudijianli> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "toudijianli_list_faburen";
    }
    @RequestMapping("/toudijianli_list_toudiren")
    public String listtoudiren()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Toudijianli.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " toudiren='"+request.getSession().getAttribute("username")+"' ";
        where += getWhere();

        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }

        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Toudijianli> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "toudijianli_list_toudiren";
    }




        @RequestMapping("/toudijianli_add")
    public String add()
    {
        int id = Request.getInt("id");
        Zhaopinxinxi readMap = serviceRead.find(id);
        request.setAttribute("readMap" , readMap);
        return "toudijianli_add";
    }

    @RequestMapping("/toudijianliadd")
    public String addWeb()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./");
        }
        int id = Request.getInt("id");
        Zhaopinxinxi readMap = serviceRead.find(id);
        request.setAttribute("readMap" , readMap);
        return "toudijianliadd";
    }


    @RequestMapping("/toudijianli_updt")
    public String updt()
    {
        int id = Request.getInt("id");
        Toudijianli mmm = service.find(id);
        request.setAttribute("mmm" , mmm);
        request.setAttribute("updtself" , 0);
        return "toudijianli_updt";
    }
    /**
     * 添加内容
     * @return
     */
    @RequestMapping("/toudijianliinsert")
    public String insert()
    {
        String tmp="";
        Toudijianli post = new Toudijianli();
        post.setBianhao(Request.get("bianhao"));

        post.setQiyemingcheng(Request.get("qiyemingcheng"));

        post.setZhiweimingcheng(Request.get("zhiweimingcheng"));

        post.setFaburen(Request.get("faburen"));

        post.setShangchuanjianli(Request.get("shangchuanjianli"));

        post.setToudirenxingming(Request.get("toudirenxingming"));

        post.setShoujihao(Request.get("shoujihao"));

        post.setToudiren(Request.get("toudiren"));

        post.setZhaopinxinxiid(Request.getInt("zhaopinxinxiid"));

        post.setAddtime(Info.getDateStr());
                service.insert(post);
        int charuid = post.getId().intValue();
        
        return showSuccess("保存成功" , Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
    * 更新内容
    * @return
    */
    @RequestMapping("/toudijianliupdate")
    public String update()
    {
        Toudijianli post = new Toudijianli();
        if(!Request.get("bianhao").equals(""))
        post.setBianhao(Request.get("bianhao"));
                if(!Request.get("qiyemingcheng").equals(""))
        post.setQiyemingcheng(Request.get("qiyemingcheng"));
                if(!Request.get("zhiweimingcheng").equals(""))
        post.setZhiweimingcheng(Request.get("zhiweimingcheng"));
                if(!Request.get("faburen").equals(""))
        post.setFaburen(Request.get("faburen"));
                if(!Request.get("shangchuanjianli").equals(""))
        post.setShangchuanjianli(Request.get("shangchuanjianli"));
                if(!Request.get("toudirenxingming").equals(""))
        post.setToudirenxingming(Request.get("toudirenxingming"));
                if(!Request.get("shoujihao").equals(""))
        post.setShoujihao(Request.get("shoujihao"));
                if(!Request.get("toudiren").equals(""))
        post.setToudiren(Request.get("toudiren"));
        
        post.setId(Request.getInt("id"));
                service.update(post);
        int charuid = post.getId().intValue();
        
        if(Request.getInt("updtself") == 1){
            return showSuccess("保存成功" , "toudijianli_updtself.do");
        }
        return showSuccess("保存成功" , Request.get("referer"));
    }
        /**
    *  删除
    */
    @RequestMapping("/toudijianli_delete")
    public String delete()
    {
        if(!checkLogin()){
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
                service.delete(id);
                return showSuccess("删除成功",request.getHeader("referer"));
    }
}
