package com.spring.controller;

import com.spring.dao.QiyeMapper;
import com.spring.entity.Qiye;
import com.spring.service.QiyeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;

import java.util.*;


/**
 * 企业
 */
@Controller
public class QiyeController extends BaseController {
    @Autowired
    private QiyeMapper dao;
    @Autowired
    private QiyeService service;

    /**
     * 后台列表页
     */
    @RequestMapping("/qiye_list")
    public String list() {
        if (!checkLogin()) {
            return showError("尚未登录", "./login.do");
        }

        String order = Request.get("order", "id");
        String sort = Request.get("sort", "desc");

        Example example = new Example(Qiye.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if (sort.equals("desc")) {
            example.orderBy(order).desc();
        } else {
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1, page);
        List<Qiye> list = service.selectPageExample(example, page, 12);
        request.setAttribute("list", list);
        assign("orderBy", order);
        assign("sort", sort);
        assign("where", where);
        return "qiye_list";
    }

    public String getWhere() {
        String where = " ";

        if ("企业".equals(session.getAttribute("cx"))) {
            where += " AND yonghuming='" + session.getAttribute("username") + "' ";
        }

        if (!Request.get("yonghuming").equals("")) {
            where += " AND yonghuming LIKE '%" + Request.get("yonghuming") + "%' ";
        }
        if (!Request.get("qiyemingcheng").equals("")) {
            where += " AND qiyemingcheng LIKE '%" + Request.get("qiyemingcheng") + "%' ";
        }
        return where;
    }


    /**
     * 前台列表页
     */
    @RequestMapping("/qiyelist")
    public String index() {
        String order = Request.get("order", "id");
        String sort = Request.get("sort", "desc");

        Example example = new Example(Qiye.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += " AND issh='是' ";
        where += getWhere();
        criteria.andCondition(where);
        if (sort.equals("desc")) {
            example.orderBy(order).desc();
        } else {
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1, page);
        List<Qiye> list = service.selectPageExample(example, page, 12);
        request.setAttribute("list", list);
        request.setAttribute("where", where);
        assign("orderBy", order);
        assign("sort", sort);
        return "qiyelist";
    }


    @RequestMapping("/qiye_add")
    public String add() {
        return "qiye_add";
    }

    @RequestMapping("/qiyeadd")
    public String addWeb() {
        return "qiyeadd";
    }


    @RequestMapping("/qiye_updt")
    public String updt() {
        int id = Request.getInt("id");
        Qiye mmm = service.find(id);
        request.setAttribute("mmm", mmm);
        request.setAttribute("updtself", 0);
        return "qiye_updt";
    }

    @RequestMapping("/qiye_updtself")
    public String updtself() {
        int id = (int) request.getSession().getAttribute("id");
        Qiye mmm = service.find(id);
        request.setAttribute("mmm", mmm);
        request.setAttribute("updtself", 1);

        return "qiye_updtself";
    }

    /**
     * 添加内容
     *
     * @return
     */
    @RequestMapping("/qiyeinsert")
    public String insert() {
        String tmp = "";
        Qiye post = new Qiye();
        post.setYonghuming(Request.get("yonghuming"));

        post.setMima(Request.get("mima"));

        post.setQiyemingcheng(Request.get("qiyemingcheng"));

        post.setQiyedizhi(Request.get("qiyedizhi"));

        post.setLianxiren(Request.get("lianxiren"));

        post.setLianxidianhua(Request.get("lianxidianhua"));

        post.setDianziyoujian(Request.get("dianziyoujian"));

        post.setYingyezhizhao(Request.get("yingyezhizhao"));

        post.setWangzhan(Request.get("wangzhan"));

        post.setGongsijianjie(util.DownloadRemoteImage.run(Request.get("gongsijianjie")));

        post.setIssh("否");

        post.setAddtime(Info.getDateStr());
        service.insert(post);
        int charuid = post.getId().intValue();

        return showSuccess("保存成功", Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
     * 更新内容
     *
     * @return
     */
    @RequestMapping("/qiyeupdate")
    public String update() {
        Qiye post = new Qiye();
        if (!Request.get("yonghuming").equals(""))
            post.setYonghuming(Request.get("yonghuming"));
        if (!Request.get("mima").equals(""))
            post.setMima(Request.get("mima"));
        if (!Request.get("qiyemingcheng").equals(""))
            post.setQiyemingcheng(Request.get("qiyemingcheng"));
        if (!Request.get("qiyedizhi").equals(""))
            post.setQiyedizhi(Request.get("qiyedizhi"));
        if (!Request.get("lianxiren").equals(""))
            post.setLianxiren(Request.get("lianxiren"));
        if (!Request.get("lianxidianhua").equals(""))
            post.setLianxidianhua(Request.get("lianxidianhua"));
        if (!Request.get("dianziyoujian").equals(""))
            post.setDianziyoujian(Request.get("dianziyoujian"));
        if (!Request.get("yingyezhizhao").equals(""))
            post.setYingyezhizhao(Request.get("yingyezhizhao"));
        if (!Request.get("wangzhan").equals(""))
            post.setWangzhan(Request.get("wangzhan"));
        if (!Request.get("gongsijianjie").equals(""))
            post.setGongsijianjie(util.DownloadRemoteImage.run(Request.get("gongsijianjie")));

        post.setId(Request.getInt("id"));
        service.update(post);
        int charuid = post.getId().intValue();

        if (Request.getInt("updtself") == 1) {
            return showSuccess("保存成功", "qiye_updtself.do");
        }
        return showSuccess("保存成功", Request.get("referer"));
    }

    /**
     * 后台详情
     */
    @RequestMapping("/qiye_detail")
    public String detail() {
        int id = Request.getInt("id");
        Qiye map = service.find(id);
        request.setAttribute("map", map);
        return "qiye_detail";
    }

    /**
     * 前台详情
     */
    @RequestMapping("/qiyedetail")
    public String detailweb() {
        int id = Request.getInt("id");
        Qiye map = service.find(id);

        request.setAttribute("map", map);
        return "qiyedetail";
    }

    /**
     * 删除
     */
    @RequestMapping("/qiye_delete")
    public String delete() {
        if (!checkLogin()) {
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
        service.delete(id);
        return showSuccess("删除成功", request.getHeader("referer"));
    }
}
