package com.spring.controller;

import com.spring.dao.GonggaofenleiMapper;
import com.spring.entity.Gonggaofenlei;
import com.spring.service.GonggaofenleiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;
import java.util.*;



/**
 * 公告分类 */
@Controller
public class GonggaofenleiController extends BaseController
{
    @Autowired
    private GonggaofenleiMapper dao;
    @Autowired
    private GonggaofenleiService service;

    /**
     *  后台列表页
     *
     */
    @RequestMapping("/gonggaofenlei_list")
    public String list()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }

        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Gonggaofenlei.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Gonggaofenlei> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "gonggaofenlei_list";
    }

    public String getWhere()
    {
        String where = " ";

        return where;
    }





        @RequestMapping("/gonggaofenlei_add")
    public String add()
    {
        return "gonggaofenlei_add";
    }



    @RequestMapping("/gonggaofenlei_updt")
    public String updt()
    {
        int id = Request.getInt("id");
        Gonggaofenlei mmm = service.find(id);
        request.setAttribute("mmm" , mmm);
        request.setAttribute("updtself" , 0);
        return "gonggaofenlei_updt";
    }
    /**
     * 添加内容
     * @return
     */
    @RequestMapping("/gonggaofenleiinsert")
    public String insert()
    {
        String tmp="";
        Gonggaofenlei post = new Gonggaofenlei();
        post.setFenleimingcheng(Request.get("fenleimingcheng"));


        post.setAddtime(Info.getDateStr());
                service.insert(post);
        int charuid = post.getId().intValue();
        
        return showSuccess("保存成功" , Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
    * 更新内容
    * @return
    */
    @RequestMapping("/gonggaofenleiupdate")
    public String update()
    {
        Gonggaofenlei post = new Gonggaofenlei();
        if(!Request.get("fenleimingcheng").equals(""))
        post.setFenleimingcheng(Request.get("fenleimingcheng"));
        
        post.setId(Request.getInt("id"));
                service.update(post);
        int charuid = post.getId().intValue();
        
        if(Request.getInt("updtself") == 1){
            return showSuccess("保存成功" , "gonggaofenlei_updtself.do");
        }
        return showSuccess("保存成功" , Request.get("referer"));
    }
        /**
    *  删除
    */
    @RequestMapping("/gonggaofenlei_delete")
    public String delete()
    {
        if(!checkLogin()){
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
                service.delete(id);
                return showSuccess("删除成功",request.getHeader("referer"));
    }
}
