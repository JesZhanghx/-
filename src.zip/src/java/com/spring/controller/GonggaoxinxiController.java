package com.spring.controller;

import com.spring.dao.GonggaoxinxiMapper;
import com.spring.entity.Gonggaoxinxi;
import com.spring.service.GonggaoxinxiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;
import java.util.*;



/**
 * 公告信息 */
@Controller
public class GonggaoxinxiController extends BaseController
{
    @Autowired
    private GonggaoxinxiMapper dao;
    @Autowired
    private GonggaoxinxiService service;

    /**
     *  后台列表页
     *
     */
    @RequestMapping("/gonggaoxinxi_list")
    public String list()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }

        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Gonggaoxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Gonggaoxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "gonggaoxinxi_list";
    }

    public String getWhere()
    {
        String where = " ";

            if(!Request.get("biaoti").equals("")) {
            where += " AND biaoti LIKE '%"+Request.get("biaoti")+"%' ";
        }
                if(!Request.get("fenlei").equals("")) {
            where += " AND fenlei ='"+Request.get("fenlei")+"' ";
        }
            return where;
    }

    @RequestMapping("/gonggaoxinxi_list_tianjiaren")
    public String listtianjiaren()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Gonggaoxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " tianjiaren='"+request.getSession().getAttribute("username")+"' ";
        where += getWhere();

        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }

        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Gonggaoxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "gonggaoxinxi_list_tianjiaren";
    }


    /**
    *  前台列表页
    *
    */
    @RequestMapping("/gonggaoxinxilist")
    public String index()
    {
        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Gonggaoxinxi.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Gonggaoxinxi> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        request.setAttribute("where" , where);
        assign("orderBy" , order);
        assign("sort" , sort);
        return "gonggaoxinxilist";
    }


        @RequestMapping("/gonggaoxinxi_add")
    public String add()
    {
        return "gonggaoxinxi_add";
    }



    @RequestMapping("/gonggaoxinxi_updt")
    public String updt()
    {
        int id = Request.getInt("id");
        Gonggaoxinxi mmm = service.find(id);
        request.setAttribute("mmm" , mmm);
        request.setAttribute("updtself" , 0);
        return "gonggaoxinxi_updt";
    }
    /**
     * 添加内容
     * @return
     */
    @RequestMapping("/gonggaoxinxiinsert")
    public String insert()
    {
        String tmp="";
        Gonggaoxinxi post = new Gonggaoxinxi();
        post.setBiaoti(Request.get("biaoti"));

        post.setFenlei(Request.get("fenlei"));

        post.setTianjiaren(Request.get("tianjiaren"));

        post.setNeirong(util.DownloadRemoteImage.run(Request.get("neirong")));


        post.setAddtime(Info.getDateStr());
                service.insert(post);
        int charuid = post.getId().intValue();
        
        return showSuccess("保存成功" , Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
    * 更新内容
    * @return
    */
    @RequestMapping("/gonggaoxinxiupdate")
    public String update()
    {
        Gonggaoxinxi post = new Gonggaoxinxi();
        if(!Request.get("biaoti").equals(""))
        post.setBiaoti(Request.get("biaoti"));
                if(!Request.get("fenlei").equals(""))
        post.setFenlei(Request.get("fenlei"));
                if(!Request.get("tianjiaren").equals(""))
        post.setTianjiaren(Request.get("tianjiaren"));
                if(!Request.get("neirong").equals(""))
        post.setNeirong(util.DownloadRemoteImage.run(Request.get("neirong")));
    
        post.setId(Request.getInt("id"));
                service.update(post);
        int charuid = post.getId().intValue();
        
        if(Request.getInt("updtself") == 1){
            return showSuccess("保存成功" , "gonggaoxinxi_updtself.do");
        }
        return showSuccess("保存成功" , Request.get("referer"));
    }
    /**
     *  后台详情
     */
    @RequestMapping("/gonggaoxinxi_detail")
    public String detail()
    {
        int id = Request.getInt("id");
        Gonggaoxinxi map = service.find(id);
        request.setAttribute("map" , map);
        return "gonggaoxinxi_detail";
    }
    /**
     *  前台详情
     */
    @RequestMapping("/gonggaoxinxidetail")
    public String detailweb()
    {
        int id = Request.getInt("id");
        Gonggaoxinxi map = service.find(id);
        
        request.setAttribute("map" , map);
        return "gonggaoxinxidetail";
    }
        /**
    *  删除
    */
    @RequestMapping("/gonggaoxinxi_delete")
    public String delete()
    {
        if(!checkLogin()){
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
                service.delete(id);
                return showSuccess("删除成功",request.getHeader("referer"));
    }
}
