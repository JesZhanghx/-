package com.spring.controller;

import dao.Query;
import dao.CommDAO;
import com.alibaba.fastjson.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import util.Request;

import java.util.List;
import java.util.Map;

/**
 * 公共路由
 */
@Controller
public class CommonController extends BaseController{
    @RequestMapping(value = "/checkno")
    @ResponseBody
    public String checkon()
    {
        String table = request.getParameter("table");
        String col   = request.getParameter("col");
        String checktype = request.getParameter("checktype");
        String value = request.getParameter(col);
        if(checktype.equals("insert")){
            if(Query.make(table).where(col , value).count() > 0){
                return "false";
            }else{
                return "true";
            }
        }else if(checktype.equals("update")){
            String id = request.getParameter("id") == null ? "" : request.getParameter("id");
            if(Query.make(table).where(col , value).where("id" , "neq" , id).count() > 0){
                return "false";
            }else{
                return "true";
            }
        }
        return "false";
    }

    @RequestMapping("/sh")
    @ResponseBody
    public String sh()
    {
        String yuan=request.getParameter("yuan");
        String id=request.getParameter("id");
        String tablename=request.getParameter("tablename");
        String sql="";
        if(yuan.equals("是"))
        {
            sql="update "+tablename+" set issh='否' where id="+id;
        }
        else
        {
            sql="update "+tablename+" set issh='是' where id="+id;
        }
        new CommDAO().commOper(sql);
        return "<script>location.href='"+request.getHeader("Referer")+"';</script>";
    }

    /**
     * 获取表的某行数据
     * @return
     */
    @RequestMapping("/tableAjax")
    @ResponseBody
    public String tableFind()
    {
        String table = request.getParameter("table");
        String id = request.getParameter("id");
        Map map = Query.make(table).where("id" , id).find();
        //JSONObject json = JSONObject.parse(map);
        return JSON.toJSONString(map);//.toString();
    }

    @RequestMapping("/selectUpdateSearch")
    @ResponseBody
    public String selectUpdateSearch()
    {
        String table = Request.get("table");
        Query query = Query.make(table);

        JSONObject where = JSON.parseObject(Request.get("where"));
        for(Map.Entry entry:where.entrySet())
        {
            String key = (String)entry.getKey();
            Object value = entry.getValue();
            if(value instanceof JSONObject)
            {
                JSONObject w = (JSONObject) value;
                query.where(key , w.getString("exp") , w.getString("value"));
            }else if(value instanceof JSONArray){
                JSONArray  w = (JSONArray) value;
                query.where(key , (String) w.get(0) , w.get(1));
            }else{
                query.where(key , value);
            }
        }

        List list = query.order("id desc").limit(50).select();
        return JSON.toJSONString(list);
    }
}
