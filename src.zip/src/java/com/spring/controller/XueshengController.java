package com.spring.controller;

import com.spring.dao.XueshengMapper;
import com.spring.entity.Xuesheng;
import com.spring.service.XueshengService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;

import java.util.*;


/**
 * 学生
 */
@Controller
public class XueshengController extends BaseController {
    @Autowired
    private XueshengMapper dao;
    @Autowired
    private XueshengService service;

    /**
     * 后台列表页
     */
    @RequestMapping("/xuesheng_list")
    public String list() {
        if (!checkLogin()) {
            return showError("尚未登录", "./login.do");
        }

        String order = Request.get("order", "id");
        String sort = Request.get("sort", "desc");

        Example example = new Example(Xuesheng.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if (sort.equals("desc")) {
            example.orderBy(order).desc();
        } else {
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1, page);
        List<Xuesheng> list = service.selectPageExample(example, page, 12);

        request.setAttribute("list", list);
        assign("orderby", order);
        assign("sort", sort);
        assign("where", where);
        return "xuesheng_list";
    }

    public String getWhere() {
        String where = " ";

        if ("学生".equals(session.getAttribute("cx"))) {
            where += " AND xuehao='" + session.getAttribute("username") + "' ";
        }

        if (!Request.get("xuehao").equals("")) {
            where += " AND xuehao LIKE '%" + Request.get("xuehao") + "%' ";
        }
        if (!Request.get("zhuanye").equals("")) {
            where += " AND zhuanye ='" + Request.get("zhuanye") + "' ";
        }
        return where;
    }


    /**
     * 导入模块
     */
    @RequestMapping("/xuesheng_import")
    public String imports() {
        return "xuesheng_import";
    }

    @RequestMapping("/xuesheng_importfile")
    public String importFile() {
        util.Execl xls = new util.Execl();
        xls.addCol("xuehao", "学号");
        xls.addCol("mima", "密码");
        xls.addCol("xingming", "姓名");
        xls.addCol("xingbie", "性别");
        xls.addCol("banji", "班级");
        xls.addCol("zhuanye", "专业");
        xls.addCol("sanfangxieyihao", "三方协议号");
        xls.addCol("shoujihao", "手机号");

        List<Map> list = new ArrayList();
        xls.addData(list);
        xls.export("xueshengtemplate", response);
        return "success";
    }

    @RequestMapping("/xuesheng_add")
    public String add() {
        return "xuesheng_add";
    }


    @RequestMapping("/xuesheng_updt")
    public String updt() {
        int id = Request.getInt("id");
        Xuesheng mmm = service.find(id);
        request.setAttribute("mmm", mmm);
        request.setAttribute("updtself", 0);
        return "xuesheng_updt";
    }

    @RequestMapping("/xuesheng_updtself")
    public String updtself() {
        int id = (int) request.getSession().getAttribute("id");
        Xuesheng mmm = service.find(id);
        request.setAttribute("mmm", mmm);
        request.setAttribute("updtself", 1);

        return "xuesheng_updtself";
    }

    /**
     * 添加内容
     *
     * @return
     */
    @RequestMapping("/xueshenginsert")
    public String insert() {
        String tmp = "";
        Xuesheng post = new Xuesheng();
        post.setXuehao(Request.get("xuehao"));

        post.setMima(Request.get("mima"));

        post.setXingming(Request.get("xingming"));

        post.setXingbie(Request.get("xingbie"));

        post.setBanji(Request.get("banji"));

        post.setZhuanye(Request.get("zhuanye"));

        post.setSanfangxieyihao(Request.get("sanfangxieyihao"));

        post.setShoujihao(Request.get("shoujihao"));


        post.setAddtime(Info.getDateStr());
        service.insert(post);
        int charuid = post.getId().intValue();

        return showSuccess("保存成功", Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
     * 更新内容
     *
     * @return
     */
    @RequestMapping("/xueshengupdate")
    public String update() {
        Xuesheng post = new Xuesheng();
        if (!Request.get("xuehao").equals(""))
            post.setXuehao(Request.get("xuehao"));
        if (!Request.get("mima").equals(""))
            post.setMima(Request.get("mima"));
        if (!Request.get("xingming").equals(""))
            post.setXingming(Request.get("xingming"));
        if (!Request.get("xingbie").equals(""))
            post.setXingbie(Request.get("xingbie"));
        if (!Request.get("banji").equals(""))
            post.setBanji(Request.get("banji"));
        if (!Request.get("zhuanye").equals(""))
            post.setZhuanye(Request.get("zhuanye"));
        if (!Request.get("sanfangxieyihao").equals(""))
            post.setSanfangxieyihao(Request.get("sanfangxieyihao"));
        if (!Request.get("shoujihao").equals(""))
            post.setShoujihao(Request.get("shoujihao"));

        post.setId(Request.getInt("id"));
        service.update(post);
        int charuid = post.getId().intValue();

        if (Request.getInt("updtself") == 1) {
            return showSuccess("保存成功", "xuesheng_updtself.do");
        }
        return showSuccess("保存成功", Request.get("referer"));
    }

    @RequestMapping("/xuesheng_batch")
    public String batch() {
        if (request.getParameter("delete") != null) {
            String[] ids = request.getParameterValues("ids");
            if (ids != null) Query.make("xuesheng").where("id", "in", ids).delete();
        }
        return showSuccess("批量处理成功", request.getHeader("referer"));
    }

    /**
     * 删除
     */
    @RequestMapping("/xuesheng_delete")
    public String delete() {
        if (!checkLogin()) {
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
        service.delete(id);
        return showSuccess("删除成功", request.getHeader("referer"));
    }
}
