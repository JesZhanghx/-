package com.spring.controller;

import com.spring.dao.DiquMapper;
import com.spring.entity.Diqu;
import com.spring.service.DiquService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;
import java.util.*;



/**
 * 地区 */
@Controller
public class DiquController extends BaseController
{
    @Autowired
    private DiquMapper dao;
    @Autowired
    private DiquService service;

    /**
     *  后台列表页
     *
     */
    @RequestMapping("/diqu_list")
    public String list()
    {
        if(!checkLogin()){
            return showError("尚未登录" , "./login.do");
        }

        String order = Request.get("order" , "id");
        String sort  = Request.get("sort" , "desc");

        Example example = new Example(Diqu.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if(sort.equals("desc")){
            example.orderBy(order).desc();
        }else{
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1 , page);
        List<Diqu> list = service.selectPageExample(example , page , 12);
        request.setAttribute("list" , list);
        assign("orderBy" , order);
        assign("sort" , sort);
        assign("where" , where);
        return "diqu_list";
    }

    public String getWhere()
    {
        String where = " ";

            if(!Request.get("quyumingcheng").equals("")) {
            where += " AND quyumingcheng LIKE '%"+Request.get("quyumingcheng")+"%' ";
        }
            return where;
    }





        @RequestMapping("/diqu_add")
    public String add()
    {
        return "diqu_add";
    }



    @RequestMapping("/diqu_updt")
    public String updt()
    {
        int id = Request.getInt("id");
        Diqu mmm = service.find(id);
        request.setAttribute("mmm" , mmm);
        request.setAttribute("updtself" , 0);
        return "diqu_updt";
    }
    /**
     * 添加内容
     * @return
     */
    @RequestMapping("/diquinsert")
    public String insert()
    {
        String tmp="";
        Diqu post = new Diqu();
        post.setQuyumingcheng(Request.get("quyumingcheng"));


        post.setAddtime(Info.getDateStr());
                service.insert(post);
        int charuid = post.getId().intValue();
        
        return showSuccess("保存成功" , Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
    * 更新内容
    * @return
    */
    @RequestMapping("/diquupdate")
    public String update()
    {
        Diqu post = new Diqu();
        if(!Request.get("quyumingcheng").equals(""))
        post.setQuyumingcheng(Request.get("quyumingcheng"));
        
        post.setId(Request.getInt("id"));
                service.update(post);
        int charuid = post.getId().intValue();
        
        if(Request.getInt("updtself") == 1){
            return showSuccess("保存成功" , "diqu_updtself.do");
        }
        return showSuccess("保存成功" , Request.get("referer"));
    }
        /**
    *  删除
    */
    @RequestMapping("/diqu_delete")
    public String delete()
    {
        if(!checkLogin()){
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
                service.delete(id);
                return showSuccess("删除成功",request.getHeader("referer"));
    }
}
