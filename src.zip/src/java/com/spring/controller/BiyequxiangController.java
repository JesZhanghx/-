package com.spring.controller;

import com.spring.dao.BiyequxiangMapper;
import com.spring.entity.Biyequxiang;
import com.spring.service.BiyequxiangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import tk.mybatis.mapper.entity.Example;
import util.Request;
import util.Info;
import dao.Query;

import java.util.*;


import com.spring.entity.Xuesheng;
import com.spring.service.XueshengService;

/**
 * 毕业去向
 */
@Controller
public class BiyequxiangController extends BaseController {
    @Autowired
    private BiyequxiangMapper dao;
    @Autowired
    private BiyequxiangService service;

    @Autowired
    private XueshengService serviceRead;

    /**
     * 后台列表页
     */
    @RequestMapping("/biyequxiang_list")
    public String list() {
        if (!checkLogin()) {
            return showError("尚未登录", "./login.do");
        }

        String order = Request.get("order", "id");
        String sort = Request.get("sort", "desc");

        Example example = new Example(Biyequxiang.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " 1=1 ";
        where += getWhere();
        criteria.andCondition(where);
        if (sort.equals("desc")) {
            example.orderBy(order).desc();
        } else {
            example.orderBy(order).asc();
        }
        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1, page);
        List<Biyequxiang> list = service.selectPageExample(example, page, 12);
        request.setAttribute("list", list);
        assign("orderBy", order);
        assign("sort", sort);
        assign("where", where);
        return "biyequxiang_list";
    }

    public String getWhere() {
        String where = " ";

        if ("学生".equals(session.getAttribute("cx"))) {
            where += " AND xuehao='" + session.getAttribute("username") + "' ";
        }

        if (Request.getInt("xueshengid") > 0) {
            where += " AND xueshengid='" + Request.getInt("xueshengid") + "' ";
        }

        if (!Request.get("xuehao").equals("")) {
            where += " AND xuehao LIKE '%" + Request.get("xuehao") + "%' ";
        }
        if (!Request.get("fangxiang").equals("")) {
            where += " AND fangxiang ='" + Request.get("fangxiang") + "' ";
        }
        if (!Request.get("diqu").equals("")) {
            where += " AND diqu ='" + Request.get("diqu") + "' ";
        }
        return where;
    }

    @RequestMapping("/biyequxiang_list_tianxieren")
    public String listtianxieren() {
        if (!checkLogin()) {
            return showError("尚未登录", "./login.do");
        }
        String order = Request.get("order", "id");
        String sort = Request.get("sort", "desc");

        Example example = new Example(Biyequxiang.class);
        Example.Criteria criteria = example.createCriteria();
        String where = " tianxieren='" + request.getSession().getAttribute("username") + "' ";
        where += getWhere();

        criteria.andCondition(where);
        if (sort.equals("desc")) {
            example.orderBy(order).desc();
        } else {
            example.orderBy(order).asc();
        }

        int page = request.getParameter("page") == null ? 1 : Integer.valueOf(request.getParameter("page"));
        page = Math.max(1, page);
        List<Biyequxiang> list = service.selectPageExample(example, page, 12);
        request.setAttribute("list", list);
        assign("orderBy", order);
        assign("sort", sort);
        assign("where", where);
        return "biyequxiang_list_tianxieren";
    }


    @RequestMapping("/biyequxiang_add")
    public String add() {
        int id = Request.getInt("id");
        Xuesheng readMap = serviceRead.find(id);
        request.setAttribute("readMap", readMap);
        return "biyequxiang_add";
    }


    @RequestMapping("/biyequxiang_updt")
    public String updt() {
        int id = Request.getInt("id");
        Biyequxiang mmm = service.find(id);
        request.setAttribute("mmm", mmm);
        request.setAttribute("updtself", 0);
        return "biyequxiang_updt";
    }

    /**
     * 添加内容
     *
     * @return
     */
    @RequestMapping("/biyequxianginsert")
    public String insert() {
        String tmp = "";
        Biyequxiang post = new Biyequxiang();
        post.setXuehao(Request.get("xuehao"));

        post.setXingming(Request.get("xingming"));

        post.setBanji(Request.get("banji"));

        post.setFangxiang(Request.get("fangxiang"));

        post.setDiqu(Request.get("diqu"));

        post.setSanfangxieyihao(Request.get("sanfangxieyihao"));

        post.setJiuyeqiye(Request.get("jiuyeqiye"));

        post.setTianxieren(Request.get("tianxieren"));

        post.setXueshengid(Request.getInt("xueshengid"));

        post.setAddtime(Info.getDateStr());
        service.insert(post);
        int charuid = post.getId().intValue();
        Query.execute("UPDATE xuesheng SET sanfangxieyihao='" + request.getParameter("sanfangxieyihao") + "' WHERE id='" + request.getParameter("xueshengid") + "'");


        return showSuccess("保存成功", Request.get("referer").equals("") ? request.getHeader("referer") : Request.get("referer"));
    }

    /**
     * 更新内容
     *
     * @return
     */
    @RequestMapping("/biyequxiangupdate")
    public String update() {
        Biyequxiang post = new Biyequxiang();
        if (!Request.get("xuehao").equals(""))
            post.setXuehao(Request.get("xuehao"));
        if (!Request.get("xingming").equals(""))
            post.setXingming(Request.get("xingming"));
        if (!Request.get("banji").equals(""))
            post.setBanji(Request.get("banji"));
        if (!Request.get("fangxiang").equals(""))
            post.setFangxiang(Request.get("fangxiang"));
        if (!Request.get("diqu").equals(""))
            post.setDiqu(Request.get("diqu"));
        if (!Request.get("sanfangxieyihao").equals(""))
            post.setSanfangxieyihao(Request.get("sanfangxieyihao"));
        if (!Request.get("jiuyeqiye").equals(""))
            post.setJiuyeqiye(Request.get("jiuyeqiye"));
        if (!Request.get("tianxieren").equals(""))
            post.setTianxieren(Request.get("tianxieren"));

        post.setId(Request.getInt("id"));
        service.update(post);
        int charuid = post.getId().intValue();

        if (Request.getInt("updtself") == 1) {
            return showSuccess("保存成功", "biyequxiang_updtself.do");
        }
        return showSuccess("保存成功", Request.get("referer"));
    }

    /**
     * 删除
     */
    @RequestMapping("/biyequxiang_delete")
    public String delete() {
        if (!checkLogin()) {
            return showError("尚未登录");
        }
        int id = Request.getInt("id");
        //delete_before
        service.delete(id);
        return showSuccess("删除成功", request.getHeader("referer"));
    }
}
