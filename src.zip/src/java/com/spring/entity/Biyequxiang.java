package com.spring.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "biyequxiang")
public class Biyequxiang implements Serializable {
    @GeneratedValue(generator = "JDBC") // 自增的主键映射
    @Id
    @Column(name = "id",insertable=false)
    private Integer id;

    @Column(name = "xuehao")
    private String xuehao;
    @Column(name = "xingming")
    private String xingming;
    @Column(name = "banji")
    private String banji;
    @Column(name = "fangxiang")
    private String fangxiang;
    @Column(name = "diqu")
    private String diqu;
    @Column(name = "sanfangxieyihao")
    private String sanfangxieyihao;
    @Column(name = "jiuyeqiye")
    private String jiuyeqiye;
    @Column(name = "tianxieren")
    private String tianxieren;
    private Integer xueshengid;

    @Column(name = "addtime")
    private String addtime;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getXuehao() {
        return xuehao;
    }
    public void setXuehao(String xuehao) {
        this.xuehao = xuehao == null ? "" : xuehao.trim();
    }

    public String getXingming() {
        return xingming;
    }
    public void setXingming(String xingming) {
        this.xingming = xingming == null ? "" : xingming.trim();
    }

    public String getBanji() {
        return banji;
    }
    public void setBanji(String banji) {
        this.banji = banji == null ? "" : banji.trim();
    }

    public String getFangxiang() {
        return fangxiang;
    }
    public void setFangxiang(String fangxiang) {
        this.fangxiang = fangxiang == null ? "" : fangxiang.trim();
    }

    public String getDiqu() {
        return diqu;
    }
    public void setDiqu(String diqu) {
        this.diqu = diqu == null ? "" : diqu.trim();
    }

    public String getSanfangxieyihao() {
        return sanfangxieyihao;
    }
    public void setSanfangxieyihao(String sanfangxieyihao) {
        this.sanfangxieyihao = sanfangxieyihao == null ? "" : sanfangxieyihao.trim();
    }

    public String getJiuyeqiye() {
        return jiuyeqiye;
    }
    public void setJiuyeqiye(String jiuyeqiye) {
        this.jiuyeqiye = jiuyeqiye == null ? "" : jiuyeqiye.trim();
    }

    public String getTianxieren() {
        return tianxieren;
    }
    public void setTianxieren(String tianxieren) {
        this.tianxieren = tianxieren == null ? "" : tianxieren.trim();
    }
    public Integer getXueshengid() {
        return xueshengid;
    }
    public void setXueshengid(Integer xueshengid) {
        this.xueshengid = xueshengid == null ? 0 : xueshengid;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
