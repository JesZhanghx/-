package com.spring.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "qiye")
public class Qiye implements Serializable {
    @GeneratedValue(generator = "JDBC") // 自增的主键映射
    @Id
    @Column(name = "id",insertable=false)
    private Integer id;

    @Column(name = "yonghuming")
    private String yonghuming;
    @Column(name = "mima")
    private String mima;
    @Column(name = "qiyemingcheng")
    private String qiyemingcheng;
    @Column(name = "qiyedizhi")
    private String qiyedizhi;
    @Column(name = "lianxiren")
    private String lianxiren;
    @Column(name = "lianxidianhua")
    private String lianxidianhua;
    @Column(name = "dianziyoujian")
    private String dianziyoujian;
    @Column(name = "yingyezhizhao")
    private String yingyezhizhao;
    @Column(name = "wangzhan")
    private String wangzhan;
    @Column(name = "gongsijianjie")
    private String gongsijianjie;
    private String issh;

    @Column(name = "addtime")
    private String addtime;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getYonghuming() {
        return yonghuming;
    }
    public void setYonghuming(String yonghuming) {
        this.yonghuming = yonghuming == null ? "" : yonghuming.trim();
    }

    public String getMima() {
        return mima;
    }
    public void setMima(String mima) {
        this.mima = mima == null ? "" : mima.trim();
    }

    public String getQiyemingcheng() {
        return qiyemingcheng;
    }
    public void setQiyemingcheng(String qiyemingcheng) {
        this.qiyemingcheng = qiyemingcheng == null ? "" : qiyemingcheng.trim();
    }

    public String getQiyedizhi() {
        return qiyedizhi;
    }
    public void setQiyedizhi(String qiyedizhi) {
        this.qiyedizhi = qiyedizhi == null ? "" : qiyedizhi.trim();
    }

    public String getLianxiren() {
        return lianxiren;
    }
    public void setLianxiren(String lianxiren) {
        this.lianxiren = lianxiren == null ? "" : lianxiren.trim();
    }

    public String getLianxidianhua() {
        return lianxidianhua;
    }
    public void setLianxidianhua(String lianxidianhua) {
        this.lianxidianhua = lianxidianhua == null ? "" : lianxidianhua.trim();
    }

    public String getDianziyoujian() {
        return dianziyoujian;
    }
    public void setDianziyoujian(String dianziyoujian) {
        this.dianziyoujian = dianziyoujian == null ? "" : dianziyoujian.trim();
    }

    public String getYingyezhizhao() {
        return yingyezhizhao;
    }
    public void setYingyezhizhao(String yingyezhizhao) {
        this.yingyezhizhao = yingyezhizhao == null ? "" : yingyezhizhao.trim();
    }

    public String getWangzhan() {
        return wangzhan;
    }
    public void setWangzhan(String wangzhan) {
        this.wangzhan = wangzhan == null ? "" : wangzhan.trim();
    }

    public String getGongsijianjie() {
        return gongsijianjie;
    }
    public void setGongsijianjie(String gongsijianjie) {
        this.gongsijianjie = gongsijianjie == null ? "" : gongsijianjie.trim();
    }
    public String getIssh() {
        return issh;
    }
    public void setIssh(String issh) {
        this.issh = issh == null ? "" : issh.trim();
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
