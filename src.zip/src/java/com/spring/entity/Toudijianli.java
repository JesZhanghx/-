package com.spring.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "toudijianli")
public class Toudijianli implements Serializable {
    @GeneratedValue(generator = "JDBC") // 自增的主键映射
    @Id
    @Column(name = "id",insertable=false)
    private Integer id;

    @Column(name = "bianhao")
    private String bianhao;
    @Column(name = "qiyemingcheng")
    private String qiyemingcheng;
    @Column(name = "zhiweimingcheng")
    private String zhiweimingcheng;
    @Column(name = "faburen")
    private String faburen;
    @Column(name = "shangchuanjianli")
    private String shangchuanjianli;
    @Column(name = "toudirenxingming")
    private String toudirenxingming;
    @Column(name = "shoujihao")
    private String shoujihao;
    @Column(name = "toudiren")
    private String toudiren;
    private Integer zhaopinxinxiid;

    @Column(name = "addtime")
    private String addtime;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBianhao() {
        return bianhao;
    }
    public void setBianhao(String bianhao) {
        this.bianhao = bianhao == null ? "" : bianhao.trim();
    }

    public String getQiyemingcheng() {
        return qiyemingcheng;
    }
    public void setQiyemingcheng(String qiyemingcheng) {
        this.qiyemingcheng = qiyemingcheng == null ? "" : qiyemingcheng.trim();
    }

    public String getZhiweimingcheng() {
        return zhiweimingcheng;
    }
    public void setZhiweimingcheng(String zhiweimingcheng) {
        this.zhiweimingcheng = zhiweimingcheng == null ? "" : zhiweimingcheng.trim();
    }

    public String getFaburen() {
        return faburen;
    }
    public void setFaburen(String faburen) {
        this.faburen = faburen == null ? "" : faburen.trim();
    }

    public String getShangchuanjianli() {
        return shangchuanjianli;
    }
    public void setShangchuanjianli(String shangchuanjianli) {
        this.shangchuanjianli = shangchuanjianli == null ? "" : shangchuanjianli.trim();
    }

    public String getToudirenxingming() {
        return toudirenxingming;
    }
    public void setToudirenxingming(String toudirenxingming) {
        this.toudirenxingming = toudirenxingming == null ? "" : toudirenxingming.trim();
    }

    public String getShoujihao() {
        return shoujihao;
    }
    public void setShoujihao(String shoujihao) {
        this.shoujihao = shoujihao == null ? "" : shoujihao.trim();
    }

    public String getToudiren() {
        return toudiren;
    }
    public void setToudiren(String toudiren) {
        this.toudiren = toudiren == null ? "" : toudiren.trim();
    }
    public Integer getZhaopinxinxiid() {
        return zhaopinxinxiid;
    }
    public void setZhaopinxinxiid(Integer zhaopinxinxiid) {
        this.zhaopinxinxiid = zhaopinxinxiid == null ? 0 : zhaopinxinxiid;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
