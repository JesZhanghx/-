package com.spring.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Table(name = "zhaopinxinxi")
public class Zhaopinxinxi implements Serializable {
    @GeneratedValue(generator = "JDBC") // 自增的主键映射
    @Id
    @Column(name = "id",insertable=false)
    private Integer id;

    @Column(name = "bianhao")
    private String bianhao;
    @Column(name = "qiyemingcheng")
    private String qiyemingcheng;
    @Column(name = "lianxidianhua")
    private String lianxidianhua;
    @Column(name = "lianxiren")
    private String lianxiren;
    @Column(name = "xueliyaoqiu")
    private String xueliyaoqiu;
    @Column(name = "xingbie")
    private String xingbie;
    @Column(name = "zhiweimingcheng")
    private String zhiweimingcheng;
    @Column(name = "zhiweiyaoqiu")
    private String zhiweiyaoqiu;
    @Column(name = "gongzuodidian")
    private String gongzuodidian;
    @Column(name = "zhaopairenshu")
    private Integer zhaopairenshu;
    @Column(name = "xinjin")
    private String xinjin;
    @Column(name = "qitadaiyu")
    private String qitadaiyu;
    @Column(name = "faburen")
    private String faburen;
    private Integer qiyeid;

    @Column(name = "addtime")
    private String addtime;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBianhao() {
        return bianhao;
    }
    public void setBianhao(String bianhao) {
        this.bianhao = bianhao == null ? "" : bianhao.trim();
    }

    public String getQiyemingcheng() {
        return qiyemingcheng;
    }
    public void setQiyemingcheng(String qiyemingcheng) {
        this.qiyemingcheng = qiyemingcheng == null ? "" : qiyemingcheng.trim();
    }

    public String getLianxidianhua() {
        return lianxidianhua;
    }
    public void setLianxidianhua(String lianxidianhua) {
        this.lianxidianhua = lianxidianhua == null ? "" : lianxidianhua.trim();
    }

    public String getLianxiren() {
        return lianxiren;
    }
    public void setLianxiren(String lianxiren) {
        this.lianxiren = lianxiren == null ? "" : lianxiren.trim();
    }

    public String getXueliyaoqiu() {
        return xueliyaoqiu;
    }
    public void setXueliyaoqiu(String xueliyaoqiu) {
        this.xueliyaoqiu = xueliyaoqiu == null ? "" : xueliyaoqiu.trim();
    }

    public String getXingbie() {
        return xingbie;
    }
    public void setXingbie(String xingbie) {
        this.xingbie = xingbie == null ? "" : xingbie.trim();
    }

    public String getZhiweimingcheng() {
        return zhiweimingcheng;
    }
    public void setZhiweimingcheng(String zhiweimingcheng) {
        this.zhiweimingcheng = zhiweimingcheng == null ? "" : zhiweimingcheng.trim();
    }

    public String getZhiweiyaoqiu() {
        return zhiweiyaoqiu;
    }
    public void setZhiweiyaoqiu(String zhiweiyaoqiu) {
        this.zhiweiyaoqiu = zhiweiyaoqiu == null ? "" : zhiweiyaoqiu.trim();
    }

    public String getGongzuodidian() {
        return gongzuodidian;
    }
    public void setGongzuodidian(String gongzuodidian) {
        this.gongzuodidian = gongzuodidian == null ? "" : gongzuodidian.trim();
    }

    public Integer getZhaopairenshu() {
        return zhaopairenshu;
    }
    public void setZhaopairenshu(Integer zhaopairenshu) {
        this.zhaopairenshu = zhaopairenshu == null ? 0 : zhaopairenshu;
    }

    public String getXinjin() {
        return xinjin;
    }
    public void setXinjin(String xinjin) {
        this.xinjin = xinjin == null ? "" : xinjin.trim();
    }

    public String getQitadaiyu() {
        return qitadaiyu;
    }
    public void setQitadaiyu(String qitadaiyu) {
        this.qitadaiyu = qitadaiyu == null ? "" : qitadaiyu.trim();
    }

    public String getFaburen() {
        return faburen;
    }
    public void setFaburen(String faburen) {
        this.faburen = faburen == null ? "" : faburen.trim();
    }
    public Integer getQiyeid() {
        return qiyeid;
    }
    public void setQiyeid(Integer qiyeid) {
        this.qiyeid = qiyeid == null ? 0 : qiyeid;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
